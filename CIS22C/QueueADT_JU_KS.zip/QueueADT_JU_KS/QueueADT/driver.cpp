#include <iostream>
#include "LinkedList.h"
#include "Stack.h"
#include "Queue.h"

using namespace std;

/* Lab 3B(Kishore Srinivas & Jnana Uhuru)
the driver function that shows the stacks and queue in use
@return 0 when the program is done with the demonstration
*/
int main() {
	LinkedNode<int> a(3);
	LinkedNode<int> b(56);
	LinkedNode<int> c(-10);
	LinkedNode<int> d(2);
	LinkedNode<int> e(4);
	LinkedNode<int> f(234);
	LinkedNode<int> g(2);

	Stack<int> intStack;
	cout << "--- STACK of INTEGERS ---" << endl;
	cout << "PUSH: " << a.getData() << endl << endl;
	intStack.push(a);
	cout << "peek: " << intStack.peek() << endl << endl;
	cout << "PUSH: " << b.getData() << endl;
	cout << "PUSH: " << c.getData() << endl;
	cout << "PUSH: " << d.getData() << endl << endl;
	intStack.push(b);
	intStack.push(c);
	intStack.push(d);
	cout << "peek: " << intStack.peek() << endl << endl;
	cout << "pop: " << intStack.pop() << endl;
	cout << "pop: " << intStack.pop() << endl << endl;
	cout << "peek: " << intStack.peek() << endl << endl;
	cout << intStack;
	cout << "emptying stack..." << endl;
	intStack.empty();
	cout << intStack << endl;

	LinkedNode<string> s1("Jnana");
	LinkedNode<string> s2("Allison");
	LinkedNode<string> s3("xyz");
	LinkedNode<string> s4("Jake");
	LinkedNode<string> s5("abcdef");
	LinkedNode<string> s6("Teacher");
	LinkedNode<string> s7("C");

	Stack<string> stringStack;
	cout << "--- STACK of STRINGS ---" << endl;
	cout << "PUSH: " << a.getData() << endl << endl;
	stringStack.push(s1);
	cout << "peek: " << stringStack.peek() << endl << endl;
	cout << "PUSH: " << s2.getData() << endl;
	cout << "PUSH: " << s3.getData() << endl;
	cout << "PUSH: " << s4.getData() << endl << endl;
	stringStack.push(s2);
	stringStack.push(s3);
	stringStack.push(s4);
	cout << "peek: " << stringStack.peek() << endl << endl;
	cout << "pop: " << stringStack.pop() << endl;
	cout << "pop: " << stringStack.pop() << endl << endl;
	cout << "peek: " << stringStack.peek() << endl << endl;
	cout << stringStack;
	cout << "emptying stack..." << endl;
	stringStack.empty();
	cout << stringStack << endl;

	LinkedNode<Currency>* ptr1 = new LinkedNode<Currency>(Rupee(14, 10));
	LinkedNode<Currency>* ptr2 = new LinkedNode<Currency>(Rupee(23, 50));
	LinkedNode<Currency>* ptr3 = new LinkedNode<Currency>(Rupee(43, 20));
	LinkedNode<Currency>* ptr4 = new LinkedNode<Currency>(Rupee(10, 15));
	LinkedNode<Currency>* ptr5 = new LinkedNode<Currency>(Rupee(7, 12));
	LinkedNode<Currency>* ptr6 = new LinkedNode<Currency>(Rupee(0, 10));
	LinkedNode<Currency>* ptr7 = new LinkedNode<Currency>(Rupee(10, 1));

	cout << "--- QUEUE of RUPEES ---" << endl;
	Queue<Currency> currQueue;
	cout << "ENQUEUE: " << ptr1->getData() << endl;
	cout << "ENQUEUE: " << ptr2->getData() << endl;
	cout << "ENQUEUE: " << ptr3->getData() << endl << endl;
	currQueue.enqueue(*ptr1);
	currQueue.enqueue(*ptr2);
	currQueue.enqueue(*ptr3);
	cout << "front: " << currQueue.getFront() << endl;
	cout << "rear: " << currQueue.getRear() << endl << endl;
	cout << "ENQUEUE: " << ptr4->getData() << endl;
	cout << "ENQUEUE: " << ptr5->getData() << endl;
	cout << "ENQUEUE: " << ptr6->getData() << endl;
	cout << "ENQUEUE: " << ptr7->getData() << endl << endl;
	currQueue.enqueue(*ptr4);
	currQueue.enqueue(*ptr5);
	currQueue.enqueue(*ptr6);
	currQueue.enqueue(*ptr7);
	cout << "front: " << currQueue.getFront() << endl;
	cout << "rear: " << currQueue.getRear() << endl << endl;
	cout << "dequeue: " << currQueue.dequeue() << endl;
	cout << "dequeue: " << currQueue.dequeue() << endl << endl;
	cout << "front: " << currQueue.getFront() << endl;
	cout << "rear: " << currQueue.getRear() << endl << endl;
	cout << currQueue;
	cout << "emptying queue..." << endl;
	currQueue.empty();
	cout << currQueue << endl;

	system("pause");
	return 0;
}